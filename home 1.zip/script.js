'use strict'

let append = () => {
    let newItem = document.createElement('li');
    newItem.innerText = ('NEW ITEM');
    document.getElementById('list').appendChild(newItem);
}

let startAppend = () => {
    let newItem = document.createElement('li');
    let firstItem = document.getElementById('list').firstChild;
    newItem.innerText = ('NEW NEW ITEM');
    document.getElementById('list').insertBefore(newItem,firstItem);
}

let remove = () => {
    let removeItem = document.getElementById('list');
    removeItem.removeChild(removeItem.lastChild);
}

let first = (view) => {
    let firstItem = document.getElementById('list').firstChild;

    if(view){
        firstItem.innerHTML = "<b style='color:red;'>" + firstItem.innerText + "</b>";
    }else{
        firstItem.innerHTML = firstItem.innerText;
    }
}

let last = (view) => {
    let lastItem = document.getElementById('list').lastChild;
    if(view){
        lastItem.innerHTML = "<b style='color:red;'>" + lastItem.innerText + "</b>";
    }else{
        lastItem.innerHTML = lastItem.innerText;
    }
}


let count = -1;


let next = () => {
    count++;

    first(false);
    last(false)

    let nextItem = document.getElementsByTagName('li');
    let len = nextItem.length;

    if(count == len ){
        count = 0;
        nextItem[count].innerHTML = "<b style='color:green;'>" + nextItem[count].innerText + "</b>";
        nextItem[len-1].innerHTML = nextItem[len-1].innerText;
    }else{
        nextItem[count].innerHTML = "<b style='color:green;'>" + nextItem[count].innerText + "</b>";
        nextItem[count].previousSibling.innerHTML = nextItem[count].previousSibling.innerText;
    }
}

let previous = () => {
    count--;

    first(false);
    last(false)

    let previousItem = document.getElementsByTagName('li');
    let len = previousItem.length;

    if(count < 0 ){
        count = len -1;
        previousItem[count].innerHTML = "<b style='color:green;'>" + previousItem[count].innerText+"</b>";
        previousItem[0].innerHTML = previousItem[0].innerText;
    }else{
        previousItem[count].innerHTML = "<b style='color:green;'>" + previousItem[count].innerText + "</b>";
        previousItem[count].nextSibling.innerHTML = previousItem[count].nextSibling.innerText;
    }
}

// можно было намного компактнее написать , если время больше уделить)